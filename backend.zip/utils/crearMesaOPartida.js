import { v4 as uuid } from "uuid";

export function crearMesa(mesasCreadas) {
    const mesaId = uuid();

    const nuevaMesa = {
        id: mesaId,
        numeroDeMesa: mesasCreadas + 1,
        partidaId: null,
        estado: "vacia",
        password: null,
        "numeroJugadores": null,
        "jugadores":[]
    }

    return nuevaMesa;
}

export function crearPartida(mesaId) {
    const id = uuid();
    const nuevaPartida = {
        id,
        mesaId,
        fase: null,
        rondaActual: 1,
        cartasJugadas: [],
        estado: "sinCrear",
        ganadorRonda: null,
        jugadores: [
        ],
        triunfo: null,
        mazo: [],
        mazoRestante: [],
        turnoJugador: null
    }
    return nuevaPartida;
}