import { guardarDB, leerDB } from '../utils/db.js'
import { mezclarArray, mezclarMazoYRepartirCartas } from '../utils/mezclarMazoYRepartirCartas.js';


export const enviarPartida = async (req, res) => {
    try {
        const db = await leerDB();
        const { partidaId } = req.query;
        const partida = db.partidas.find(p => p.id === partidaId);
        if (!partida) return res.status(400).json({ error: 'No existe partida' });

        res.status(200).json(partida);
    } catch (error) {
        console.error('Error al enviar una partida', error);
        res.status(400).json({ error: 'Error al enviar la partida' });
    }
}


export const ingresarPartida = async (req, res) => {
    try {
        const db = await leerDB();
        const { usuarioId, mesaId, partidaId } = req.body;

        const partida = db.partidas.find(p => p.id === partidaId);
        if (!partida) return res.status(400).json({ error: 'No se encontró partida' });

        const jugadorPartida = partida.jugadores.find(j => j.usuarioId === usuarioId);
        if (!jugadorPartida) return res.status(400).json({ error: 'No se encontró jugador' });

        const mesa = db.mesas.find(m => m.id === mesaId);
        if (!mesa) return res.status(400).json({ error: 'No se encontró mesa' });

        let cartas = jugadorPartida.cartas;

        if (cartas.length === 0) {
            const { cartasRepartidas, mazoMezclado } = mezclarMazoYRepartirCartas();
            jugadorPartida.cartas.push(...cartasRepartidas);
            partida.mazoRestante = mazoMezclado;
        }

        //aca deberia ser mayor o igual a 2
        if (partida.jugadores.length >= 1) {
            partida.fase = 'Descarte';
        }

        await guardarDB(db);
        res.status(200).json(cartas);
    } catch (error) {
        console.log(error);
    }
}


export const descartarCartas = async (req, res) => {
    try {
        const db = await leerDB();
        const { usuarioId, partidaId, cartas } = req.body;

        const partida = db.partidas.find(p => p.id === partidaId);
        if(!partida) return res.status(401).json({error: 'No se encontró partida'});

        const jugador = partida.jugador.find(j => j.usuarioId === usuarioId);
        if(!jugador) return res.status(401).json({error: 'No se encontró jugador '})

        jugador.cartas = jugador.cartas.filter(c => !cartas.includes(c.id));

        const nuevasCartas = [];

        for(let i = 0; i < cartas,length; i++) {
            const nuevaCarta = partida.mazoRestante.pop();
            if(nuevaCarta) nuevasCartas.push(nuevaCarta);
        }

        jugador.cartas.push(...nuevasCartas);
        
    } catch (error) {

    }
}