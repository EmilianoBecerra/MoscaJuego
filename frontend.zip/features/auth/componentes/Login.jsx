import { useLogin } from "../hooks/useLogin";
import styles from "../Login.module.css";

const Login = () => {
  const { formData, error, handleChange, handleLogin, handleClickRegister } =
    useLogin();

  return (
    <form onSubmit={handleLogin} className={styles.formulario}>
      <input
        type="text"
        name="usuario"
        placeholder="Usuario"
        value={formData.usuario}
        onChange={handleChange}
        className={styles.usuario}
        required
      />
      <input
        type="password"
        name="password"
        placeholder="Contraseña"
        value={formData.password}
        onChange={handleChange}
        className={styles.pass}
        autoComplete="on"
        required
      />
      <p style={{ color: "rgba(255, 40, 40, 0.65)", fontSize: "10px" }}>
        {error}
      </p>
      <button type="submit" className={styles.btnIngresar}>
        Ingresar
      </button>
      <button
        type="button"
        onClick={handleClickRegister}
        className={styles.btnRegistrarse}
      >
        Registrarse
      </button>
    </form>
  );
};

export default Login;
