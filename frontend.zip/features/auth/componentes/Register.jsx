import styles from '../Register.module.css';
import { useRegister } from '../hooks/useRegister';

const Register = () => {
  
  const {formData, handleSubmit, handleChange} = useRegister();

  return (
    <form onSubmit={handleSubmit} className={styles.formulario}>
      <input
        type='text'
        name='usuario'
        value={formData.usuario}
        onChange={handleChange}
        id='username'
        placeholder='Usuario'
        className={styles.usuario}
        required
      />
      <input
        type='password'
        name='password'
        autoComplete='on'
        value={formData.password}
        onChange={handleChange}
        id='password'
        placeholder='Contraseña'
        className={styles.pass}
        required
      />
      <button className={styles.btnIngresar}> Registrarse </button>
    </form>
  );
};

export default Register;
